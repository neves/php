<?

class MyClass
{
}

?>